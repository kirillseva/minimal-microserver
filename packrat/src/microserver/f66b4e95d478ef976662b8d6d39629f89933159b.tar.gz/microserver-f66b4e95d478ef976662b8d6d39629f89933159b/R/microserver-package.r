#' Microserver is a package that builds on the httupv library
#' and aims to provide a minimal set of tools to get a JSON-based
#' REST API off the ground.
#'
#' @name microserver
#' @docType package
#' @import httpuv jsonlite
NULL
