Microserver [![Build Status](https://travis-ci.org/robertzk/microserver.svg?branch=master)](https://travis-ci.org/robertzk/microserver) [![Coverage Status](https://coveralls.io/repos/robertzk/microserver/badge.png)](https://coveralls.io/r/robertzk/microserver)
===========

Minimal R server mimicking Ruby's Sinatra gem.

